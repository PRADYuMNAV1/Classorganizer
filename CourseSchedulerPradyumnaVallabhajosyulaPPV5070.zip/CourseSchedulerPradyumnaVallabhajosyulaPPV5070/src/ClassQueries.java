
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.ResultSet;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author prady
 */

public class ClassQueries {
    private static Connection connection;
    private static PreparedStatement getAllClasses;
    private static PreparedStatement addClass;
    private static PreparedStatement getAllCourseCodes;
    private static PreparedStatement getClassSeats;
    private static ResultSet resultSet;
   
     public static void addClass(ClassEntry Cls) {
        connection = DBConnection.getConnection();
        try {
            addClass = connection.prepareStatement("insert into app.class (semester, coursecode, seats) values (?, ?, ?)");
            addClass.setString(1, Cls.getSemester());
            addClass.setString(2, Cls.getCourseCode());
            addClass.setInt(3, Cls.getSeats());
           
            addClass.executeUpdate();
        }
        catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
    }
     
    public static ArrayList<String> getAllCourseCodes(String semester) {
        connection = DBConnection.getConnection();
        ArrayList<String> courseCodes = new ArrayList<String>();
        try {
            getAllCourseCodes = connection.prepareStatement("select coursecode from app.class where (semester) = (?)");
            getAllCourseCodes.setString(1, semester);
            resultSet = getAllCourseCodes.executeQuery();
            while (resultSet.next()) {
                courseCodes.add(resultSet.getString(1));
            }
        }
        catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
        return courseCodes;
   
    }
    public static int getClassSeats(String semester, String courseCode){
       connection = DBConnection.getConnection();
       int count =0;
        try {
            getClassSeats = connection.prepareStatement("select seats from app.class where semester = (?)  and cousecode = (?)");
            //getClassSeats = connection.prepareStatement("select seats from app.classentry");
            getClassSeats.setString(1, semester);
            getClassSeats.setString(2, courseCode);
            resultSet = getClassSeats.executeQuery();
            if(resultSet.next())
                count = Integer.parseInt(resultSet.getString("seats"));
           
        }
        catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
        return count;
    }
}
