/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author prady
 */
public class ClassDescription {
    private String courseCode;
    private String courseDescription;
    private int seats;
    
    public ClassDescription(String courseCode,String courseDescription, int seats){
    
        this.courseDescription = courseDescription;
        this.courseCode = courseCode;
        this.seats = seats;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public int getSeats() {
        return seats;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }
    
}
